package lexer;

import static org.junit.Assert.*;

import  org.hamcrest.*;
import org.hamcrest.core.Is;
import org.junit.Test;

public class PostfixTest {


	@Test
	public void testPostfix() {
		Postfix post = new Postfix("22+33++\n");
		post.evaluPostfix();
	}

	

}
