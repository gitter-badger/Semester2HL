package lexer;

import java.util.Stack;

public class Postfix extends ExprLexer{
	private static Stack<Double> stack = new Stack<Double>();
	private static int value1;	//Für die brechnung von plus minus usw.
	private static int value2;	//Für die berechnung von plus minus usw.
	private static Token token;
	public Postfix(String post){
		super(post);
	}
	
	public double evaluPostfix() {
		do{
			token =  nextToken();
			if(token.getType()==DIV){
				
			}
			if(token.getType()==MINUS){
				
			}
		}while(token.getType()!=NL);
		
		
		return 0.0;
		
	}
	
}
